package Config;

public class Config {

    public static final String flipkartUrl ="https://www.flipkart.com/";
    public static final String username ="shrisampath16@gmail.com";
    public static final String password ="Parkavenue@1";

}
